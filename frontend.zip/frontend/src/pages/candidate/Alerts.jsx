import { useState } from 'react';
import { Bell, Plus, Briefcase, Trash2, Edit2 } from 'lucide-react';
import Sidebar from '../../components/common/Sidebar';
import Modal from '../../components/common/Modal';

const Alerts = () => {
  const [alerts, setAlerts] = useState([
    {
      id: 1,
      title: 'Senior Nurse Jobs in New York',
      keywords: 'Senior Nurse',
      location: 'New York',
      jobType: 'Full-time',
      criteria: 'Senior Nurse • New York • Full-time',
      frequency: 'Daily',
      active: true,
      matchingJobs: 12,
    },
    {
      id: 2,
      title: 'Physical Therapist Jobs',
      keywords: 'Physical Therapist',
      location: 'Any Location',
      jobType: 'Full-time',
      criteria: 'Physical Therapist • Any Location • Full-time',
      frequency: 'Weekly',
      active: true,
      matchingJobs: 8,
    },
    {
      id: 3,
      title: 'Part-time Medical Jobs',
      keywords: 'Medical',
      location: 'Chicago',
      jobType: 'Part-time',
      criteria: 'Medical • Chicago • Part-time',
      frequency: 'Daily',
      active: false,
      matchingJobs: 5,
    },
  ]);

  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [selectedAlert, setSelectedAlert] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    keywords: '',
    location: '',
    jobType: 'All Types',
    frequency: 'Daily'
  });

  const handleToggleAlert = (alertId) => {
    setAlerts(alerts.map(alert =>
      alert.id === alertId ? { ...alert, active: !alert.active } : alert
    ));
  };

  const handleCreateAlert = () => {
    const newAlert = {
      id: alerts.length + 1,
      title: formData.title,
      keywords: formData.keywords,
      location: formData.location,
      jobType: formData.jobType,
      criteria: `${formData.keywords} • ${formData.location} • ${formData.jobType}`,
      frequency: formData.frequency,
      active: true,
      matchingJobs: Math.floor(Math.random() * 20) + 1
    };
    setAlerts([...alerts, newAlert]);
    setShowCreateModal(false);
    setFormData({ title: '', keywords: '', location: '', jobType: 'All Types', frequency: 'Daily' });
    setSuccessMessage('Job alert created successfully!');
    setShowSuccessModal(true);
  };

  const handleEditClick = (alert) => {
    setSelectedAlert(alert);
    setFormData({
      title: alert.title,
      keywords: alert.keywords,
      location: alert.location,
      jobType: alert.jobType,
      frequency: alert.frequency
    });
    setShowEditModal(true);
  };

  const handleUpdateAlert = () => {
    setAlerts(alerts.map(alert =>
      alert.id === selectedAlert.id
        ? {
            ...alert,
            title: formData.title,
            keywords: formData.keywords,
            location: formData.location,
            jobType: formData.jobType,
            criteria: `${formData.keywords} • ${formData.location} • ${formData.jobType}`,
            frequency: formData.frequency
          }
        : alert
    ));
    setShowEditModal(false);
    setSelectedAlert(null);
    setFormData({ title: '', keywords: '', location: '', jobType: 'All Types', frequency: 'Daily' });
    setSuccessMessage('Job alert updated successfully!');
    setShowSuccessModal(true);
  };

  const handleDeleteClick = (alert) => {
    setSelectedAlert(alert);
    setShowDeleteModal(true);
  };

  const handleConfirmDelete = () => {
    setAlerts(alerts.filter(alert => alert.id !== selectedAlert.id));
    setShowDeleteModal(false);
    setSelectedAlert(null);
    setSuccessMessage('Job alert deleted successfully!');
    setShowSuccessModal(true);
  };

  const renderAlertForm = () => (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Alert Title</label>
        <input
          type="text"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          placeholder="e.g., Senior Nurse Jobs"
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Job Title/Keywords</label>
        <input
          type="text"
          value={formData.keywords}
          onChange={(e) => setFormData({ ...formData, keywords: e.target.value })}
          placeholder="e.g., Nurse, Doctor"
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
        <input
          type="text"
          value={formData.location}
          onChange={(e) => setFormData({ ...formData, location: e.target.value })}
          placeholder="e.g., New York"
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Job Type</label>
        <select
          value={formData.jobType}
          onChange={(e) => setFormData({ ...formData, jobType: e.target.value })}
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
        >
          <option>All Types</option>
          <option>Full-time</option>
          <option>Part-time</option>
          <option>Contract</option>
        </select>
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Alert Frequency</label>
        <select
          value={formData.frequency}
          onChange={(e) => setFormData({ ...formData, frequency: e.target.value })}
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
        >
          <option>Daily</option>
          <option>Weekly</option>
          <option>Instant</option>
        </select>
      </div>
    </div>
  );

  return (
    <div>
      <Sidebar />
      <div className="ml-64 min-h-screen bg-gray-50 p-6">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Job Alerts</h1>
            <p className="text-gray-600 mt-2">Get notified when new jobs match your preferences</p>
          </div>
          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center space-x-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-6 py-3 rounded-lg hover:from-cyan-600 hover:to-blue-700 font-medium"
          >
            <Plus className="w-5 h-5" />
            <span>Create Alert</span>
          </button>
        </div>

        {/* Alerts List */}
        <div className="space-y-4">
          {alerts.map((alert) => (
            <div key={alert.id} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="text-xl font-bold text-gray-900">{alert.title}</h3>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        alert.active
                          ? 'bg-green-100 text-green-700'
                          : 'bg-gray-100 text-gray-600'
                      }`}
                    >
                      {alert.active ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                  <p className="text-gray-600 mb-3">{alert.criteria}</p>
                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <span className="flex items-center space-x-1">
                      <Bell className="w-4 h-4" />
                      <span>{alert.frequency}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <Briefcase className="w-4 h-4" />
                      <span>{alert.matchingJobs} matching jobs</span>
                    </span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => handleEditClick(alert)}
                    className="p-2 hover:bg-gray-100 rounded-lg text-gray-600"
                  >
                    <Edit2 className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => handleDeleteClick(alert)}
                    className="p-2 hover:bg-red-50 rounded-lg text-red-600"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                  <label className="relative inline-flex items-center cursor-pointer ml-2">
                    <input
                      type="checkbox"
                      checked={alert.active}
                      onChange={() => handleToggleAlert(alert.id)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-cyan-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
                  </label>
                </div>
              </div>
            </div>
          ))}
        </div>

        {alerts.length === 0 && (
          <div className="bg-white rounded-xl p-12 text-center shadow-sm border border-gray-100">
            <Bell className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">No Job Alerts</h2>
            <p className="text-gray-600 mb-6">Create alerts to get notified about new job opportunities</p>
            <button
              onClick={() => setShowCreateModal(true)}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-6 py-3 rounded-lg hover:from-cyan-600 hover:to-blue-700 font-medium"
            >
              Create Your First Alert
            </button>
          </div>
        )}

        {/* Create Alert Modal */}
        {showCreateModal && (
          <Modal
            isOpen={showCreateModal}
            onClose={() => setShowCreateModal(false)}
            title="Create New Job Alert"
          >
            {renderAlertForm()}
            <div className="flex justify-end space-x-3 pt-4">
              <button
                onClick={() => setShowCreateModal(false)}
                className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateAlert}
                className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-lg hover:from-cyan-600 hover:to-blue-700"
              >
                Create Alert
              </button>
            </div>
          </Modal>
        )}

        {/* Edit Alert Modal */}
        {showEditModal && selectedAlert && (
          <Modal
            isOpen={showEditModal}
            onClose={() => setShowEditModal(false)}
            title="Edit Job Alert"
          >
            {renderAlertForm()}
            <div className="flex justify-end space-x-3 pt-4">
              <button
                onClick={() => setShowEditModal(false)}
                className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleUpdateAlert}
                className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-lg hover:from-cyan-600 hover:to-blue-700"
              >
                Update Alert
              </button>
            </div>
          </Modal>
        )}

        {/* Delete Confirmation Modal */}
        {showDeleteModal && selectedAlert && (
          <Modal
            isOpen={showDeleteModal}
            onClose={() => setShowDeleteModal(false)}
            title="Delete Job Alert"
          >
            <div className="space-y-4">
              <p className="text-gray-600">
                Are you sure you want to delete the alert <span className="font-semibold">{selectedAlert.title}</span>? You will stop receiving notifications for matching jobs.
              </p>
              <div className="flex justify-end space-x-3 pt-4">
                <button
                  onClick={() => setShowDeleteModal(false)}
                  className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmDelete}
                  className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                  Delete
                </button>
              </div>
            </div>
          </Modal>
        )}

        {/* Success Modal */}
        {showSuccessModal && (
          <Modal
            isOpen={showSuccessModal}
            onClose={() => setShowSuccessModal(false)}
            title="Success"
          >
            <div className="text-center py-6">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-10 h-10 text-green-600" />
              </div>
              <p className="text-lg text-gray-900">{successMessage}</p>
              <button
                onClick={() => setShowSuccessModal(false)}
                className="mt-6 px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-lg hover:from-cyan-600 hover:to-blue-700"
              >
                Close
              </button>
            </div>
          </Modal>
        )}
      </div>
    </div>
  );
};

export default Alerts;
