import { useState } from 'react';
import { Heart, MapPin, Briefcase, DollarSign, Clock, Trash2, FileText, Calendar, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import Sidebar from '../../components/common/Sidebar';
import Modal from '../../components/common/Modal';

const SavedJobs = () => {
  const [savedJobs, setSavedJobs] = useState([
    {
      id: 1,
      title: 'Senior Registered Nurse',
      company: 'Manhattan Hospital',
      location: 'New York, NY',
      type: 'Full-time',
      salary: '$75,000 - $95,000',
      posted: '2 days ago',
      saved: true,
    },
    {
      id: 2,
      title: 'Physical Therapist',
      company: 'Wellness Rehab Center',
      location: 'Los Angeles, CA',
      type: 'Full-time',
      salary: '$65,000 - $85,000',
      posted: '1 week ago',
      saved: true,
    },
    {
      id: 3,
      title: 'Medical Lab Technician',
      company: 'HealthCare Labs',
      location: 'Chicago, IL',
      type: 'Part-time',
      salary: '$45,000 - $55,000',
      posted: '3 days ago',
      saved: true,
    },
  ]);

  const [showRemoveModal, setShowRemoveModal] = useState(false);
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [selectedJob, setSelectedJob] = useState(null);
  const [applicationData, setApplicationData] = useState({
    coverLetter: '',
    expectedSalary: '',
    availability: ''
  });

  const handleRemoveClick = (job) => {
    setSelectedJob(job);
    setShowRemoveModal(true);
  };

  const handleConfirmRemove = () => {
    setSavedJobs(savedJobs.filter(job => job.id !== selectedJob.id));
    setShowRemoveModal(false);
    setSelectedJob(null);
  };

  const handleApplyClick = (job) => {
    setSelectedJob(job);
    setShowApplyModal(true);
  };

  const handleSubmitApplication = () => {
    console.log('Application submitted:', {
      job: selectedJob,
      application: applicationData
    });
    setSuccessMessage(`Application submitted for ${selectedJob.title}!`);
    setShowSuccessModal(true);
    setShowApplyModal(false);
    setApplicationData({ coverLetter: '', expectedSalary: '', availability: '' });
    setSelectedJob(null);
  };

  return (
    <div>
      <Sidebar />
      <div className="ml-64 min-h-screen bg-gray-50 p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Saved Jobs</h1>
          <p className="text-gray-600 mt-2">{savedJobs.length} jobs saved for later</p>
        </div>

        {savedJobs.length === 0 ? (
          <div className="bg-white rounded-xl p-12 text-center shadow-sm border border-gray-100">
            <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">No Saved Jobs</h2>
            <p className="text-gray-600 mb-6">Start saving jobs you're interested in</p>
            <Link
              to="/candidate/browse-jobs"
              className="inline-block bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-6 py-3 rounded-lg hover:from-cyan-600 hover:to-blue-700 font-medium"
            >
              Browse Jobs
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {savedJobs.map((job) => (
              <div key={job.id} className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow border border-gray-100">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="text-xl font-bold text-gray-900 mb-1">{job.title}</h3>
                        <p className="text-gray-600">{job.company}</p>
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-4">
                      <div className="flex items-center space-x-1">
                        <MapPin className="w-4 h-4" />
                        <span>{job.location}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Briefcase className="w-4 h-4" />
                        <span>{job.type}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <DollarSign className="w-4 h-4" />
                        <span>{job.salary}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>{job.posted}</span>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3">
                      <button
                        onClick={() => handleApplyClick(job)}
                        className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-6 py-2 rounded-lg hover:from-cyan-600 hover:to-blue-700 font-medium"
                      >
                        Apply Now
                      </button>
                      <Link
                        to={`/candidate/job/${job.id}`}
                        className="border border-cyan-600 text-cyan-600 px-6 py-2 rounded-lg hover:bg-cyan-50 font-medium"
                      >
                        View Details
                      </Link>
                      <button
                        onClick={() => handleRemoveClick(job)}
                        className="flex items-center space-x-2 text-red-600 hover:text-red-700 font-medium"
                      >
                        <Trash2 className="w-4 h-4" />
                        <span>Remove</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Remove Confirmation Modal */}
        {showRemoveModal && selectedJob && (
          <Modal
            isOpen={showRemoveModal}
            onClose={() => setShowRemoveModal(false)}
            title="Remove Saved Job"
          >
            <div className="space-y-4">
              <p className="text-gray-600">
                Are you sure you want to remove <span className="font-semibold">{selectedJob.title}</span> at {selectedJob.company} from your saved jobs?
              </p>
              <div className="flex justify-end space-x-3 pt-4">
                <button
                  onClick={() => setShowRemoveModal(false)}
                  className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmRemove}
                  className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                  Remove
                </button>
              </div>
            </div>
          </Modal>
        )}

        {/* Apply Modal */}
        {showApplyModal && selectedJob && (
          <Modal
            isOpen={showApplyModal}
            onClose={() => setShowApplyModal(false)}
            title={`Apply for ${selectedJob.title}`}
          >
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Cover Letter</label>
                <textarea
                  value={applicationData.coverLetter}
                  onChange={(e) => setApplicationData({ ...applicationData, coverLetter: e.target.value })}
                  placeholder="Tell us why you're a great fit for this role..."
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
                  rows="6"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Expected Salary</label>
                <input
                  type="text"
                  value={applicationData.expectedSalary}
                  onChange={(e) => setApplicationData({ ...applicationData, expectedSalary: e.target.value })}
                  placeholder="$75,000"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Available to Join</label>
                <input
                  type="date"
                  value={applicationData.availability}
                  onChange={(e) => setApplicationData({ ...applicationData, availability: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
                />
              </div>
              <div className="flex justify-end space-x-3 pt-4">
                <button
                  onClick={() => setShowApplyModal(false)}
                  className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSubmitApplication}
                  className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-lg hover:from-cyan-600 hover:to-blue-700"
                >
                  Submit Application
                </button>
              </div>
            </div>
          </Modal>
        )}

        {/* Success Modal */}
        {showSuccessModal && (
          <Modal
            isOpen={showSuccessModal}
            onClose={() => setShowSuccessModal(false)}
            title="Success"
          >
            <div className="text-center py-6">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-10 h-10 text-green-600" />
              </div>
              <p className="text-lg text-gray-900">{successMessage}</p>
              <button
                onClick={() => setShowSuccessModal(false)}
                className="mt-6 px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-lg hover:from-cyan-600 hover:to-blue-700"
              >
                Close
              </button>
            </div>
          </Modal>
        )}
      </div>
    </div>
  );
};

export default SavedJobs;
