import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Navbar from '../../components/common/Navbar';

const Home = () => {
  const navigate = useNavigate();
  const [jobTitle, setJobTitle] = useState('');
  const [city, setCity] = useState('');
  const [activeTab, setActiveTab] = useState('latest');

  const handleSearch = (e) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (jobTitle) params.append('search', jobTitle);
    if (city) params.append('location', city);
    navigate(`/jobs?${params.toString()}`);
  };

  // Popular Categories Data
  const categories = [
    { id: 1, title: 'Hospital Jobs – Doctors', icon: '🏥', positions: 8 },
    { id: 2, title: 'Hospital Management', icon: '📊', positions: 0 },
    { id: 3, title: 'Medical Colleges', icon: '🎓', positions: 12 },
    { id: 4, title: 'Allied Health', icon: '🩺', positions: 5 },
    { id: 5, title: 'Nursing', icon: '👩‍⚕️', positions: 15 },
    { id: 6, title: 'Alternative Medicine', icon: '🌿', positions: 3 },
  ];

  // Job Category Tabs
  const tabs = [
    { id: 'latest', label: 'Latest Jobs' },
    { id: 'hospital', label: 'Hospital Jobs Doctors' },
    { id: 'management', label: 'Hospital Management' },
    { id: 'colleges', label: 'Medical Colleges' },
    { id: 'allied', label: 'Allied Health' },
    { id: 'alternative', label: 'Alternative Medicine' },
    { id: 'nursing', label: 'Nursing' },
  ];

  // Popular Jobs Data
  const jobs = [
    {
      id: 1,
      title: 'Wanted Mch Neurosurgeon for Guntur',
      company: 'Hospital Jobs Doctors',
      category: 'Hospital Jobs Doctors',
      location: 'Guntur',
      salary: 'Rs. 400,000 - Rs. 600,000 / month',
      type: 'Full Time',
      featured: true,
    },
    {
      id: 2,
      title: 'Urgent Requirement: Radiologist with Fetal Medicine Expertise - Vijayawada',
      company: 'Hospital Jobs Doctors',
      category: 'Hospital Jobs Doctors',
      location: 'Vijayawada',
      salary: 'Rs. 500,000 - Rs. 600,000 / year',
      type: 'Full Time',
      featured: true,
    },
    {
      id: 3,
      title: 'Senior Cardiologist - Delhi',
      company: 'Apollo Hospitals',
      category: 'Hospital Jobs Doctors',
      location: 'Delhi',
      salary: 'Rs. 800,000 - Rs. 1,200,000 / month',
      type: 'Full Time',
      featured: false,
    },
    {
      id: 4,
      title: 'Pediatrician - Mumbai',
      company: 'Max Healthcare',
      category: 'Hospital Jobs Doctors',
      location: 'Mumbai',
      salary: 'Rs. 600,000 - Rs. 900,000 / month',
      type: 'Full Time',
      featured: false,
    },
  ];

  // How It Works Steps
  const steps = [
    {
      id: 1,
      icon: '👤',
      title: 'Register an account to start',
      description: 'Create your professional profile and set up your job preferences in minutes.',
    },
    {
      id: 2,
      icon: '🔍',
      title: 'Explore over thousands of resumes',
      description: 'Browse through thousands of qualified healthcare professionals and find the perfect fit.',
    },
    {
      id: 3,
      icon: '📋',
      title: 'Find the most suitable candidate',
      description: 'Use our advanced filters to find candidates that match your requirements.',
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section with Search */}
      <div className="relative min-h-screen bg-gradient-to-r from-blue-700 via-blue-600 to-cyan-500 flex items-center overflow-hidden">
        {/* Decorative overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-white/5 via-transparent to-white/5" />

        {/* Content */}
        <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex flex-col lg:flex-row items-center gap-10">
          {/* Left Content */}
          <div className="lg:w-1/2 text-white space-y-6">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight drop-shadow-sm">
              India's #1 Healthcare Job Platform
            </h1>
            <p className="text-lg md:text-xl text-white/90 leading-relaxed">
              Find your dream healthcare job or hire top medical talent. Connecting professionals with opportunities across India.
            </p>

            {/* Search Bar */}
            <form
              onSubmit={handleSearch}
              className="bg-white rounded-2xl shadow-2xl p-5 md:p-6 space-y-4 border border-gray-100"
            >
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="col-span-1 md:col-span-2">
                  <label className="block text-gray-700 font-semibold mb-2">Job title, keywords</label>
                  <input
                    type="text"
                    placeholder="e.g., Doctor, Nurse, Radiologist"
                    value={jobTitle}
                    onChange={(e) => setJobTitle(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 text-gray-900"
                  />
                </div>
                <div>
                  <label className="block text-gray-700 font-semibold mb-2">City</label>
                  <select
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 text-gray-900 bg-white"
                  >
                    <option value="">Select City</option>
                    <option value="bangalore">Bangalore</option>
                    <option value="delhi">Delhi</option>
                    <option value="mumbai">Mumbai</option>
                    <option value="hyderabad">Hyderabad</option>
                    <option value="pune">Pune</option>
                    <option value="chennai">Chennai</option>
                  </select>
                </div>
              </div>
              <button
                type="submit"
                className="w-full md:w-auto bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-semibold py-3 px-8 rounded-lg transition duration-300 shadow-lg"
              >
                Find Jobs
              </button>
            </form>

            {/* Browse Tags */}
            <div className="text-white/90">
              <p className="font-semibold mb-2">Browse Jobs</p>
              <p className="text-sm md:text-base leading-relaxed">
                Cardiologist, Neurologist, Gynecologist, Radiologist, Pediatrician, Orthopedic, Pulmonologist, Pharmacist
              </p>
            </div>
          </div>

          {/* Right Content - Illustration */}
          <div className="lg:w-1/2 flex justify-center">
            <div className="relative w-full max-w-md">
              <div className="bg-white/15 border border-white/20 rounded-2xl p-8 backdrop-blur-md shadow-2xl">
                <div className="w-full h-96 bg-gradient-to-br from-white/20 to-white/5 rounded-xl flex items-center justify-center">
                  <svg className="w-40 h-40 text-white/80" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
                  </svg>
                </div>
                <p className="text-center text-white mt-4 font-semibold">Healthcare Professionals</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Popular Job Categories */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center mb-12">
            <h2 className="text-4xl font-extrabold text-gray-900 mb-3">Popular Job Categories</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Explore the most in-demand medical job categories on Mcare Jobs. Whether you're a doctor, nurse, lab technician, or medical assistant, find roles that match your skills and career goals in just a few clicks.
            </p>
          </div>

          {/* Categories Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category) => (
              <div
                key={category.id}
                onClick={() => navigate('/jobs')}
                className="bg-white rounded-2xl p-6 hover:shadow-xl transition-all duration-300 cursor-pointer border border-gray-100 group"
              >
                <div className="flex items-center gap-4">
                  <div className="text-5xl">{category.icon}</div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-gray-900 group-hover:text-cyan-600 transition-colors">
                      {category.title}
                    </h3>
                    <p className="text-sm text-gray-600 mt-1">
                      {category.positions} open position{category.positions !== 1 ? 's' : ''}
                    </p>
                  </div>
                  <div className="text-cyan-500 group-hover:translate-x-1 transition-transform">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Most Popular Jobs */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center mb-10">
            <h2 className="text-4xl font-extrabold text-gray-900 mb-3">Most Popular Jobs</h2>
            <p className="text-lg text-gray-600">
              Discover the most in-demand medical job openings across India.
            </p>
            <p className="text-gray-500 mt-2 max-w-3xl mx-auto">
              From top hospitals to specialized clinics, these roles are trending among healthcare professionals. Apply now to land your next opportunity with ease.
            </p>
          </div>

          {/* Tabs */}
          <div className="flex flex-wrap gap-3 justify-center mb-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 rounded-full transition-all duration-300 font-semibold shadow-sm ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg'
                    : 'bg-white text-gray-700 border border-gray-200 hover:border-cyan-400'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Job Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {jobs.map((job) => (
              <div
                key={job.id}
                className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition duration-300 border border-gray-100 overflow-hidden"
              >
                <div className="p-6 flex flex-col gap-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-100 to-blue-100 flex items-center justify-center text-cyan-600">
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M3 9.5 12 4l9 5.5M5 10v8a1 1 0 0 0 1 1h3v-5h6v5h3a1 1 0 0 0 1-1v-8" />
                        </svg>
                      </div>
                      <div>
                        {job.featured && (
                          <span className="inline-block bg-cyan-100 text-cyan-700 text-xs font-semibold px-3 py-1 rounded-full mb-2">
                            Featured
                          </span>
                        )}
                        <h3 className="text-lg md:text-xl font-bold text-gray-900 leading-snug">{job.title}</h3>
                        <div className="text-sm text-gray-600 mt-1 flex flex-wrap gap-3 items-center">
                          <span className="font-semibold text-gray-800">{job.company}</span>
                          <span className="inline-flex items-center gap-1 text-gray-600">
                            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                            </svg>
                            {job.location}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="inline-block bg-gray-100 text-gray-700 text-xs px-3 py-1 rounded-full">
                        {job.category}
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2 text-sm text-gray-700">
                    <span className="font-semibold text-gray-900">{job.salary}</span>
                    <span className="inline-flex w-fit items-center gap-2 bg-green-100 text-green-700 text-xs font-bold px-3 py-1 rounded-full">
                      {job.type}
                    </span>
                  </div>

                  <div className="flex justify-end">
                    <button 
                      onClick={() => navigate('/jobs')}
                      className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-semibold py-2.5 px-5 rounded-lg transition shadow-md"
                    >
                      Apply Now
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Pagination/View More */}
          <div className="flex justify-center items-center gap-3">
            {[0, 1, 2, 3].map((idx) => (
              <button
                key={idx}
                className={`w-3 h-3 rounded-full ${idx === 0 ? 'bg-cyan-500' : 'bg-gray-300 hover:bg-gray-400'}`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">How It Works?</h2>
            <p className="text-lg text-gray-600 mb-4 max-w-3xl mx-auto">
              Mcare Jobs makes it simple for medical professionals to find the right job and for hospitals to hire the right talent. Whether you're a doctor, nurse, technician, or recruiter – getting started is easy. Just follow these simple steps and connect instantly.
            </p>
          </div>

          {/* Steps */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {steps.map((step) => (
              <div key={step.id} className="text-center">
                {/* Icon */}
                <div className="mb-4 flex justify-center">
                  <div className="text-6xl">{step.icon}</div>
                </div>
                {/* Title */}
                <h3 className="text-xl font-bold text-gray-900 mb-3">{step.title}</h3>
                {/* Description */}
                <p className="text-gray-600 leading-relaxed">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-cyan-500 to-blue-600">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-4xl font-bold text-white mb-4">Ready to Start Your Healthcare Career?</h2>
          <p className="text-cyan-100 text-lg mb-8">Join thousands of healthcare professionals finding their perfect job match</p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link
              to="/register"
              className="bg-white text-cyan-600 px-8 py-3 rounded-lg hover:bg-gray-100 font-medium inline-flex items-center justify-center transition shadow-lg"
            >
              <span>Create Free Account</span>
              <svg className="ml-2 w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
              </svg>
            </Link>
            <Link
              to="/jobs"
              className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-lg hover:bg-white hover:text-cyan-600 font-medium transition shadow-lg"
            >
              Browse Jobs
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-xl">M</span>
                </div>
                <span className="text-2xl font-bold text-white">MCARE</span>
              </div>
              <p className="text-gray-400">Your trusted partner in healthcare recruitment</p>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4">For Candidates</h3>
              <ul className="space-y-2">
                <li><Link to="/jobs" className="hover:text-cyan-400 transition">Browse Jobs</Link></li>
                <li><Link to="/register" className="hover:text-cyan-400 transition">Create Account</Link></li>
                <li><Link to="/login" className="hover:text-cyan-400 transition">Sign In</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4">For Employers</h3>
              <ul className="space-y-2">
                <li><Link to="/register" className="hover:text-cyan-400 transition">Post a Job</Link></li>
                <li><Link to="/login" className="hover:text-cyan-400 transition">Employer Login</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4">Company</h3>
              <ul className="space-y-2">
                <li><Link to="/about" className="hover:text-cyan-400 transition">About Us</Link></li>
                <li><Link to="/contact" className="hover:text-cyan-400 transition">Contact</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p>&copy; 2025 MCARE. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;
