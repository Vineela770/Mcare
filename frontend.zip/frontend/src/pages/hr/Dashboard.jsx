import { useState, useEffect } from 'react';
import { Users, Briefcase, FileText, TrendingUp, Clock, CheckCircle, Eye, XCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/useAuth';
import Sidebar from '../../components/common/Sidebar';

const HRDashboard = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState({
    activeJobs: 0,
    totalApplications: 0,
    interviewed: 0,
    hired: 0,
  });
  const [recentApplications, setRecentApplications] = useState([]);

  useEffect(() => {
    // TODO: Fetch from API
    const fetchData = async () => {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 0));
      setStats({
        activeJobs: 12,
        totalApplications: 245,
        interviewed: 48,
        hired: 15,
      });

      setRecentApplications([
      {
        id: 1,
        candidateName: 'Sarah Johnson',
        jobTitle: 'Senior Registered Nurse',
        appliedDate: '2 hours ago',
        status: 'New',
        experience: '5 years',
      },
      {
        id: 2,
        candidateName: 'Michael Chen',
        jobTitle: 'Physical Therapist',
        appliedDate: '5 hours ago',
        status: 'Reviewed',
        experience: '3 years',
      },
      {
        id: 3,
        candidateName: 'Emily Davis',
        jobTitle: 'Lab Technician',
        appliedDate: '1 day ago',
        status: 'Interview',
        experience: '4 years',
      },
      ]);
    };
    fetchData();
  }, []);

  const statCards = [
    { label: 'Active Jobs', value: stats.activeJobs, icon: Briefcase, color: 'cyan', link: '/hr/jobs' },
    { label: 'Total Applications', value: stats.totalApplications, icon: FileText, color: 'blue', link: '/hr/applications' },
    { label: 'Interviewed', value: stats.interviewed, icon: Users, color: 'green', link: '/hr/interviews' },
    { label: 'Hired', value: stats.hired, icon: CheckCircle, color: 'purple', link: '/hr/analytics' },
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'New': return 'bg-cyan-100 text-cyan-700';
      case 'Reviewed': return 'bg-blue-100 text-blue-700';
      case 'Interview': return 'bg-green-100 text-green-700';
      case 'Rejected': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div>
      <Sidebar />
      <div className="ml-64 min-h-screen bg-gray-50 p-6">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">HR Dashboard</h1>
          <p className="text-gray-600 mt-2">Welcome back, {user?.name}! Manage your recruitment process</p>
        </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {statCards.map((stat, index) => (
          <Link
            key={index}
            to={stat.link}
            className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow border border-gray-100"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 bg-${stat.color}-100 rounded-lg flex items-center justify-center`}>
                <stat.icon className={`w-6 h-6 text-${stat.color}-600`} />
              </div>
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
            <div className="text-gray-600 text-sm">{stat.label}</div>
          </Link>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl p-6 mb-8">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="text-white mb-4 md:mb-0">
            <h3 className="text-2xl font-bold mb-2">Need to Hire Talent?</h3>
            <p className="text-cyan-100">Post a new job and start receiving applications</p>
          </div>
          <div className="flex space-x-4">
            <Link
              to="/hr/post-job"
              className="bg-white text-cyan-600 px-6 py-3 rounded-lg hover:bg-gray-100 font-medium"
            >
              Post New Job
            </Link>
            <Link
              to="/hr/applications"
              className="bg-cyan-700 text-white px-6 py-3 rounded-lg hover:bg-cyan-800 font-medium"
            >
              Review Applications
            </Link>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Applications */}
        <div className="lg:col-span-2 bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">Recent Applications</h2>
            <Link to="/hr/applications" className="text-cyan-600 hover:text-cyan-700 font-medium text-sm">
              View All →
            </Link>
          </div>
          
          <div className="space-y-4">
            {recentApplications.map((app) => (
              <div key={app.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-cyan-300 transition-colors">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-cyan-100 to-blue-100 rounded-full flex items-center justify-center">
                    <span className="text-lg font-bold text-cyan-600">{app.candidateName.charAt(0)}</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{app.candidateName}</h3>
                    <p className="text-sm text-gray-600">{app.jobTitle} • {app.experience} experience</p>
                    <div className="flex items-center space-x-2 text-sm text-gray-500 mt-1">
                      <Clock className="w-4 h-4" />
                      <span>{app.appliedDate}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(app.status)}`}>
                    {app.status}
                  </span>
                  <button className="p-2 text-cyan-600 hover:bg-cyan-50 rounded-lg">
                    <Eye className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Stats */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h2 className="text-xl font-bold text-gray-900 mb-6">This Week</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-cyan-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <FileText className="w-5 h-5 text-cyan-600" />
                <span className="text-gray-700">New Applications</span>
              </div>
              <span className="text-xl font-bold text-cyan-600">32</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <CheckCircle className="w-5 h-5 text-blue-600" />
                <span className="text-gray-700">Shortlisted</span>
              </div>
              <span className="text-xl font-bold text-blue-600">12</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <Users className="w-5 h-5 text-green-600" />
                <span className="text-gray-700">Interviews</span>
              </div>
              <span className="text-xl font-bold text-green-600">8</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <XCircle className="w-5 h-5 text-red-600" />
                <span className="text-gray-700">Rejected</span>
              </div>
              <span className="text-xl font-bold text-red-600">15</span>
            </div>
          </div>
        </div>
      </div>
      </div>
    </div>
  );
};

export default HRDashboard;
