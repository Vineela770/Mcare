import { Link } from 'react-router-dom';
import { Search, MapPin, Briefcase, DollarSign, Clock, Building2, Star, Filter } from 'lucide-react';
import { useState } from 'react';
import Navbar from '../../components/common/Navbar';

const AllJobs = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [location, setLocation] = useState('');
  const [jobType, setJobType] = useState('all');

  const jobs = [
    {
      id: 1,
      title: 'Senior Registered Nurse',
      company: 'Manhattan Hospital',
      location: 'New York, NY',
      type: 'Full-time',
      salary: '$75,000 - $95,000',
      posted: '2 days ago',
      logo: '🏥',
    },
    {
      id: 2,
      title: 'Physical Therapist',
      company: 'Wellness Rehab Center',
      location: 'Los Angeles, CA',
      type: 'Full-time',
      salary: '$65,000 - $85,000',
      posted: '1 week ago',
      logo: '🏋️',
    },
    {
      id: 3,
      title: 'Lab Technician',
      company: 'HealthCare Labs',
      location: 'Chicago, IL',
      type: 'Part-time',
      salary: '$45,000 - $55,000',
      posted: '3 days ago',
      logo: '🔬',
    },
    {
      id: 4,
      title: 'Medical Assistant',
      company: 'City Medical Center',
      location: 'Houston, TX',
      type: 'Full-time',
      salary: '$40,000 - $50,000',
      posted: '1 day ago',
      logo: '⚕️',
    },
    {
      id: 5,
      title: 'Pharmacist',
      company: 'CVS Health',
      location: 'Boston, MA',
      type: 'Full-time',
      salary: '$110,000 - $130,000',
      posted: '5 days ago',
      logo: '💊',
    },
    {
      id: 6,
      title: 'Dental Hygienist',
      company: 'Bright Smile Dental',
      location: 'Seattle, WA',
      type: 'Part-time',
      salary: '$55,000 - $70,000',
      posted: '1 week ago',
      logo: '🦷',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      {/* Search Section */}
      <section className="bg-gradient-to-r from-cyan-500 to-blue-600 py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold text-white mb-6">Find Your Perfect Healthcare Job</h1>
          <p className="text-cyan-100 text-lg mb-8">Browse {jobs.length} open positions from top healthcare facilities</p>
          
          <div className="bg-white rounded-xl shadow-xl p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="flex items-center space-x-3 px-4 py-3 bg-gray-50 rounded-lg">
                <Search className="w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Job title or keyword"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="bg-transparent border-none outline-none w-full text-gray-700"
                />
              </div>
              <div className="flex items-center space-x-3 px-4 py-3 bg-gray-50 rounded-lg">
                <MapPin className="w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="City or state"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="bg-transparent border-none outline-none w-full text-gray-700"
                />
              </div>
              <select
                value={jobType}
                onChange={(e) => setJobType(e.target.value)}
                className="px-4 py-3 bg-gray-50 border-none rounded-lg text-gray-700 focus:ring-2 focus:ring-cyan-500"
              >
                <option value="all">All Types</option>
                <option value="full-time">Full-time</option>
                <option value="part-time">Part-time</option>
                <option value="contract">Contract</option>
              </select>
              <button className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-6 py-3 rounded-lg hover:from-cyan-600 hover:to-blue-700 font-medium">
                Search
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Jobs Grid */}
      <section className="py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl font-bold text-gray-900">Available Positions</h2>
            <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
              <Filter className="w-5 h-5" />
              <span>More Filters</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {jobs.map((job) => (
              <div key={job.id} className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow border border-gray-100">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-cyan-100 to-blue-100 rounded-lg flex items-center justify-center text-2xl">
                    {job.logo}
                  </div>
                  <button className="text-gray-300 hover:text-yellow-400">
                    <Star className="w-5 h-5" />
                  </button>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{job.title}</h3>
                <div className="flex items-center space-x-2 text-gray-600 mb-2">
                  <Building2 className="w-4 h-4" />
                  <span className="text-sm">{job.company}</span>
                </div>
                <div className="flex items-center space-x-2 text-gray-600 mb-4">
                  <MapPin className="w-4 h-4" />
                  <span className="text-sm">{job.location}</span>
                </div>
                <div className="flex items-center justify-between mb-4">
                  <span className="px-3 py-1 bg-cyan-100 text-cyan-700 rounded-full text-sm font-medium">
                    {job.type}
                  </span>
                  <div className="flex items-center space-x-1 text-gray-600 text-sm">
                    <DollarSign className="w-4 h-4" />
                    <span>{job.salary.split(' - ')[0]}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-1 text-gray-500 text-sm">
                    <Clock className="w-4 h-4" />
                    <span>{job.posted}</span>
                  </div>
                  <Link
                    to={`/job/${job.id}`}
                    className="text-cyan-600 hover:text-cyan-700 font-medium text-sm"
                  >
                    View Details →
                  </Link>
                </div>
              </div>
            ))}
          </div>

          {/* Load More */}
          <div className="text-center mt-12">
            <button className="bg-white border-2 border-cyan-500 text-cyan-600 px-8 py-3 rounded-lg hover:bg-cyan-50 font-medium">
              Load More Jobs
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AllJobs;
