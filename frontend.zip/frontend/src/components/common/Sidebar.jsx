import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/useAuth';
import {
  LayoutDashboard,
  Briefcase,
  FileText,
  User,
  Settings,
  LogOut,
  Users,
  Calendar,
  Heart,
  MessageSquare,
  Bell,
  Building2,
  UserPlus,
  List,
} from 'lucide-react';

const Sidebar = () => {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const menuItems = {
    candidate: [
      { icon: LayoutDashboard, label: 'Dashboard', path: '/candidate/dashboard' },
      { icon: Briefcase, label: 'Browse Jobs', path: '/candidate/browse-jobs' },
      { icon: FileText, label: 'My Applications', path: '/candidate/applications' },
      { icon: User, label: 'Resume', path: '/candidate/resume' },
      { icon: Heart, label: 'Saved Jobs', path: '/candidate/saved-jobs' },
      { icon: MessageSquare, label: 'Messages', path: '/candidate/messages' },
      { icon: Bell, label: 'Job Alerts', path: '/candidate/alerts' },
      { icon: Settings, label: 'Profile Settings', path: '/candidate/profile' },
    ],
    hr: [
      { icon: LayoutDashboard, label: 'Dashboard', path: '/hr/dashboard' },
      { icon: UserPlus, label: 'Post New Job', path: '/hr/post-job' },
      { icon: Briefcase, label: 'My Jobs', path: '/hr/jobs' },
      { icon: FileText, label: 'Applications', path: '/hr/applications' },
      { icon: Users, label: 'Candidates', path: '/hr/candidates' },
      { icon: Calendar, label: 'Interviews', path: '/hr/interviews' },
      { icon: MessageSquare, label: 'Messages', path: '/hr/messages' },
      { icon: Settings, label: 'Settings', path: '/hr/settings' },
    ],
    admin: [
      { icon: LayoutDashboard, label: 'Dashboard', path: '/admin/dashboard' },
      { icon: Users, label: 'Users Management', path: '/admin/users' },
      { icon: Briefcase, label: 'Jobs Management', path: '/admin/jobs' },
      { icon: Building2, label: 'Employers', path: '/admin/employers' },
      { icon: FileText, label: 'Reports', path: '/admin/reports' },
      { icon: List, label: 'Activity Log', path: '/admin/activity' },
      { icon: Settings, label: 'System Settings', path: '/admin/settings' },
    ],
  };

  const currentMenu = menuItems[user?.role] || [];

  return (
    <div className="w-64 bg-white h-screen border-r border-gray-200 flex flex-col fixed left-0 top-0 z-40">
      {/* Logo & User Info */}
      <div className="p-6 border-b border-gray-200">
        <Link to="/" className="flex items-center space-x-2 mb-4">
          <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-xl">M</span>
          </div>
          <span className="text-2xl font-bold text-gray-900">MCARE</span>
        </Link>
        <div className="flex items-center space-x-3 mt-4">
          <div className="w-10 h-10 bg-gradient-to-br from-cyan-100 to-blue-100 rounded-full flex items-center justify-center">
            <span className="text-lg font-bold text-cyan-600">{user?.name?.charAt(0) || 'U'}</span>
          </div>
          <div>
            <p className="font-semibold text-gray-900">{user?.name || 'User'}</p>
            <p className="text-sm text-gray-500 capitalize">{user?.role || 'Role'}</p>
          </div>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 p-4 overflow-y-auto">
        <div className="space-y-2">
          {currentMenu.map((item, index) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            
            return (
              <Link
                key={index}
                to={item.path}
                className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </Link>
            );
          })}
        </div>
      </nav>

      {/* Logout Button */}
      <div className="p-4 border-t border-gray-200">
        <button
          onClick={handleLogout}
          className="flex items-center space-x-3 px-4 py-3 rounded-lg w-full text-red-600 hover:bg-red-50 transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span className="font-medium">Logout</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
