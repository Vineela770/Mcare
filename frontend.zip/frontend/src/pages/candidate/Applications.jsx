import { useState, useEffect } from 'react';
import { Send, Clock, CheckCircle, XCircle, Eye, FileText, Building2, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';
import Sidebar from '../../components/common/Sidebar';

const Applications = () => {
  const [filter, setFilter] = useState('all');
  const [applications, setApplications] = useState([]);

  useEffect(() => {
    // TODO: Fetch applications from API
    const fetchApplications = async () => {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 0));
      setApplications([
      {
        id: 1,
        title: 'Senior Registered Nurse',
        company: 'Manhattan Hospital',
        location: 'New York, NY',
        appliedDate: '2024-01-05',
        status: 'Under Review',
        salary: '$75,000 - $95,000',
      },
      {
        id: 2,
        title: 'Physical Therapist',
        company: 'Wellness Rehab',
        location: 'Los Angeles, CA',
        appliedDate: '2024-01-03',
        status: 'Shortlisted',
        salary: '$65,000 - $85,000',
      },
      {
        id: 3,
        title: 'Lab Technician',
        company: 'HealthCare Labs',
        location: 'Chicago, IL',
        appliedDate: '2023-12-28',
        status: 'Interview',
        salary: '$45,000 - $55,000',
      },
      {
        id: 4,
        title: 'Medical Assistant',
        company: 'City Medical',
        location: 'Houston, TX',
        appliedDate: '2023-12-20',
        status: 'Rejected',
        salary: '$40,000 - $50,000',
      },
      ]);
    };
    fetchApplications();
  }, []);

  const stats = {
    total: applications.length,
    pending: applications.filter(a => a.status === 'Under Review').length,
    shortlisted: applications.filter(a => a.status === 'Shortlisted').length,
    interview: applications.filter(a => a.status === 'Interview').length,
  };

  const filteredApplications = filter === 'all' 
    ? applications 
    : applications.filter(a => a.status.toLowerCase() === filter);

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Under Review': return <Clock className="w-5 h-5" />;
      case 'Shortlisted': return <FileText className="w-5 h-5" />;
      case 'Interview': return <CheckCircle className="w-5 h-5" />;
      case 'Rejected': return <XCircle className="w-5 h-5" />;
      default: return <Clock className="w-5 h-5" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Under Review': return 'bg-yellow-100 text-yellow-700';
      case 'Shortlisted': return 'bg-blue-100 text-blue-700';
      case 'Interview': return 'bg-green-100 text-green-700';
      case 'Rejected': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div>
      <Sidebar />
      <div className="ml-64 min-h-screen bg-gray-50 p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">My Applications</h1>
          <p className="text-gray-600 mt-2">Track all your job applications in one place</p>
        </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-cyan-100 rounded-lg flex items-center justify-center">
              <Send className="w-6 h-6 text-cyan-600" />
            </div>
          </div>
          <div className="text-3xl font-bold text-gray-900 mb-1">{stats.total}</div>
          <div className="text-gray-600 text-sm">Total Applied</div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
              <Clock className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
          <div className="text-3xl font-bold text-gray-900 mb-1">{stats.pending}</div>
          <div className="text-gray-600 text-sm">Under Review</div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <FileText className="w-6 h-6 text-blue-600" />
            </div>
          </div>
          <div className="text-3xl font-bold text-gray-900 mb-1">{stats.shortlisted}</div>
          <div className="text-gray-600 text-sm">Shortlisted</div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <div className="text-3xl font-bold text-gray-900 mb-1">{stats.interview}</div>
          <div className="text-gray-600 text-sm">Interviews</div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 mb-6">
        <div className="flex space-x-4">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-lg font-medium ${
              filter === 'all' 
                ? 'bg-cyan-100 text-cyan-700' 
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            All Applications
          </button>
          <button
            onClick={() => setFilter('under review')}
            className={`px-4 py-2 rounded-lg font-medium ${
              filter === 'under review' 
                ? 'bg-yellow-100 text-yellow-700' 
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            Under Review
          </button>
          <button
            onClick={() => setFilter('shortlisted')}
            className={`px-4 py-2 rounded-lg font-medium ${
              filter === 'shortlisted' 
                ? 'bg-blue-100 text-blue-700' 
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            Shortlisted
          </button>
          <button
            onClick={() => setFilter('interview')}
            className={`px-4 py-2 rounded-lg font-medium ${
              filter === 'interview' 
                ? 'bg-green-100 text-green-700' 
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            Interview
          </button>
        </div>
      </div>

      {/* Applications List */}
      <div className="space-y-4">
        {filteredApplications.map((app) => (
          <div key={app.id} className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow border border-gray-100">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{app.title}</h3>
                    <div className="flex items-center space-x-4 text-gray-600 text-sm">
                      <div className="flex items-center space-x-1">
                        <Building2 className="w-4 h-4" />
                        <span>{app.company}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <MapPin className="w-4 h-4" />
                        <span>{app.location}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>Applied {app.appliedDate}</span>
                      </div>
                    </div>
                  </div>
                  <div className={`flex items-center space-x-2 px-4 py-2 rounded-full ${getStatusColor(app.status)}`}>
                    {getStatusIcon(app.status)}
                    <span className="font-medium">{app.status}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-900 font-semibold">{app.salary}</span>
                  <Link
                    to={`/candidate/application/${app.id}`}
                    className="flex items-center space-x-2 text-cyan-600 hover:text-cyan-700 font-medium"
                  >
                    <Eye className="w-4 h-4" />
                    <span>View Details</span>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredApplications.length === 0 && (
        <div className="bg-white rounded-xl p-12 text-center shadow-sm border border-gray-100">
          <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No Applications Found</h3>
          <p className="text-gray-600 mb-6">Start applying to jobs to see them here</p>
          <Link
            to="/candidate/browse-jobs"
            className="inline-block bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-6 py-3 rounded-lg hover:from-cyan-600 hover:to-blue-700 font-medium"
          >
            Browse Jobs
          </Link>
        </div>
      )}
      </div>
    </div>
  );
};

export default Applications;
