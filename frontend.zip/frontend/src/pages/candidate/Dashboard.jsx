import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Briefcase, FileText, Eye, TrendingUp, Clock, MapPin, Building2, Send } from 'lucide-react';
import { useAuth } from '../../context/useAuth';
import Sidebar from '../../components/common/Sidebar';

const CandidateDashboard = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState({
    applied: 0,
    shortlisted: 0,
    interviews: 0,
    profileViews: 0,
  });
  const [recentApplications, setRecentApplications] = useState([]);

  useEffect(() => {
    // TODO: Fetch from API
    const fetchData = async () => {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 0));
      setStats({
        applied: 15,
        shortlisted: 8,
        interviews: 3,
        profileViews: 234,
      });

      setRecentApplications([
      {
        id: 1,
        title: 'Senior Registered Nurse',
        company: 'Manhattan Hospital',
        location: 'New York, NY',
        appliedDate: '2 days ago',
        status: 'Under Review',
        logo: '🏥',
      },
      {
        id: 2,
        title: 'Physical Therapist',
        company: 'Wellness Rehab',
        location: 'Los Angeles, CA',
        appliedDate: '5 days ago',
        status: 'Shortlisted',
        logo: '🏋️',
      },
      {
        id: 3,
        title: 'Lab Technician',
        company: 'HealthCare Labs',
        location: 'Chicago, IL',
        appliedDate: '1 week ago',
        status: 'Interview',
        logo: '🔬',
      },
      ]);
    };
    fetchData();
  }, []);

  const statCards = [
    { label: 'Jobs Applied', value: stats.applied, icon: Send, color: 'cyan', link: '/candidate/applications' },
    { label: 'Shortlisted', value: stats.shortlisted, icon: FileText, color: 'blue', link: '/candidate/applications' },
    { label: 'Interviews', value: stats.interviews, icon: TrendingUp, color: 'green', link: '/candidate/applications' },
    { label: 'Profile Views', value: stats.profileViews, icon: Eye, color: 'purple', link: '/candidate/profile' },
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'Under Review': return 'bg-yellow-100 text-yellow-700';
      case 'Shortlisted': return 'bg-blue-100 text-blue-700';
      case 'Interview': return 'bg-green-100 text-green-700';
      case 'Rejected': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div>
      <Sidebar />
      <div className="ml-64 min-h-screen bg-gray-50 p-6">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Welcome back, {user?.name}!</h1>
          <p className="text-gray-600 mt-2">Track your job applications and manage your healthcare career</p>
        </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {statCards.map((stat, index) => (
          <Link
            key={index}
            to={stat.link}
            className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow border border-gray-100"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 bg-${stat.color}-100 rounded-lg flex items-center justify-center`}>
                <stat.icon className={`w-6 h-6 text-${stat.color}-600`} />
              </div>
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
            <div className="text-gray-600 text-sm">{stat.label}</div>
          </Link>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl p-6 mb-8">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="text-white mb-4 md:mb-0">
            <h3 className="text-2xl font-bold mb-2">Ready to Find Your Next Role?</h3>
            <p className="text-cyan-100">Browse thousands of healthcare jobs matched to your skills</p>
          </div>
          <div className="flex space-x-4">
            <Link
              to="/candidate/browse-jobs"
              className="bg-white text-cyan-600 px-6 py-3 rounded-lg hover:bg-gray-100 font-medium"
            >
              Browse Jobs
            </Link>
            <Link
              to="/candidate/resume"
              className="bg-cyan-700 text-white px-6 py-3 rounded-lg hover:bg-cyan-800 font-medium"
            >
              Update Resume
            </Link>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Applications */}
        <div className="lg:col-span-2 bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">Recent Applications</h2>
            <Link to="/candidate/applications" className="text-cyan-600 hover:text-cyan-700 font-medium text-sm">
              View All →
            </Link>
          </div>
          
          <div className="space-y-4">
            {recentApplications.map((app) => (
              <div key={app.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-cyan-300 transition-colors">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-cyan-100 to-blue-100 rounded-lg flex items-center justify-center text-2xl">
                    {app.logo}
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{app.title}</h3>
                    <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
                      <div className="flex items-center space-x-1">
                        <Building2 className="w-4 h-4" />
                        <span>{app.company}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <MapPin className="w-4 h-4" />
                        <span>{app.location}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>{app.appliedDate}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(app.status)}`}>
                  {app.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Links */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Quick Actions</h2>
          <div className="space-y-3">
            <Link
              to="/candidate/browse-jobs"
              className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <div className="w-10 h-10 bg-cyan-100 rounded-lg flex items-center justify-center">
                <Briefcase className="w-5 h-5 text-cyan-600" />
              </div>
              <div>
                <div className="font-medium text-gray-900">Browse Jobs</div>
                <div className="text-sm text-gray-500">Find new opportunities</div>
              </div>
            </Link>
            <Link
              to="/candidate/resume"
              className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <FileText className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <div className="font-medium text-gray-900">My Resume</div>
                <div className="text-sm text-gray-500">Update your profile</div>
              </div>
            </Link>
            <Link
              to="/candidate/saved-jobs"
              className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <FileText className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <div className="font-medium text-gray-900">Saved Jobs</div>
                <div className="text-sm text-gray-500">View bookmarked jobs</div>
              </div>
            </Link>
          </div>
        </div>
      </div>
      </div>
    </div>
  );
};

export default CandidateDashboard;
